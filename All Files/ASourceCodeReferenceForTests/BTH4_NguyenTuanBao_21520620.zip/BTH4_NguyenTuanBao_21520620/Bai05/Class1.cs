﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab04_Bai05
{
    static class PassData
    {
        public static int ID;
        public static string MSSV;
        public static string HoTen;
        public static string Khoa;
        public static float DiemTB;
        public static bool IsSuccess;
    }
}
